import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  Gamepad2, 
  Brain, 
  Zap, 
  Lock, 
  Play, 
  RotateCcw,
  Timer
} from 'lucide-react';

/* --- Quick Math Game Component --- */
const QuickMath = () => {
  const [problem, setProblem] = useState({ a: 0, b: 0, op: '+', ans: 0 });
  const [userInput, setUserInput] = useState('');
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [gameState, setGameState] = useState('idle'); // idle, playing, over

  const generateProblem = () => {
    const ops = ['+', '-', '*'];
    const op = ops[Math.floor(Math.random() * ops.length)];
    let a, b, ans;
    if (op === '*') {
      a = Math.floor(Math.random() * 12) + 2;
      b = Math.floor(Math.random() * 12) + 2;
      ans = a * b;
    } else {
      a = Math.floor(Math.random() * 50) + 10;
      b = Math.floor(Math.random() * 50) + 10;
      ans = op === '+' ? a + b : a - b;
    }
    setProblem({ a, b, op, ans });
    setUserInput('');
  };

  const startGame = () => {
    setScore(0);
    setTimeLeft(30);
    setGameState('playing');
    generateProblem();
  };

  useEffect(() => {
    let timer;
    if (gameState === 'playing' && timeLeft > 0) {
      timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
    } else if (timeLeft === 0) {
      setGameState('over');
    }
    return () => clearInterval(timer);
  }, [gameState, timeLeft]);

  const handleInput = (e) => {
    const val = e.target.value;
    setUserInput(val);
    if (parseInt(val) === problem.ans) {
      setScore(prev => prev + 10);
      generateProblem();
    }
  };

  return (
    <div className="glass-card flex flex-col items-center justify-center p-8 min-h-[400px]">
      {gameState === 'idle' && (
        <div className="text-center space-y-4">
          <Zap className="mx-auto text-yellow-500" size={48} />
          <h2 className="text-2xl font-bold">Quick Math</h2>
          <p className="text-gray-400">Solve as many as you can in 30 seconds!</p>
          <button onClick={startGame} className="glass-button">Start Challenge</button>
        </div>
      )}

      {gameState === 'playing' && (
        <div className="text-center space-y-8 w-full max-w-xs">
          <div className="flex justify-between items-center text-sm font-bold text-gray-400">
            <span className="flex items-center gap-1"><Timer size={16} /> {timeLeft}s</span>
            <span className="text-blue-400">Score: {score}</span>
          </div>
          <div className="text-5xl font-bold tracking-widest text-white">
            {problem.a} {problem.op === '*' ? '×' : problem.op} {problem.b}
          </div>
          <input
            autoFocus
            type="number"
            value={userInput}
            onChange={handleInput}
            className="w-full bg-white/5 border-2 border-white/10 rounded-2xl px-6 py-4 text-center text-3xl font-bold outline-none focus:border-blue-500 transition-all"
            placeholder="?"
          />
        </div>
      )}

      {gameState === 'over' && (
        <div className="text-center space-y-6">
          <h2 className="text-3xl font-bold">Time's Up!</h2>
          <div className="text-6xl font-black text-blue-500">{score}</div>
          <p className="text-gray-400 font-medium">Points Earned</p>
          <button onClick={startGame} className="glass-button flex items-center gap-2 mx-auto">
            <RotateCcw size={18} /> Try Again
          </button>
        </div>
      )}
    </div>
  );
};

/* --- Main Games Page --- */
const GamesPage = () => {
  const [completedTasks, setCompletedTasks] = useState(0);
  const [activeGame, setActiveGame] = useState(null);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await axios.get('/api/stats');
        setCompletedTasks(res.data.completedTasks);
      } catch (err) { console.error(err); }
    };
    fetchStats();
  }, []);

  const games = [
    { 
      id: 'math', 
      name: 'Quick Math', 
      desc: 'Test your speed with arithmetic calculations.', 
      req: 3, 
      color: 'blue' 
    },
    { 
      id: 'memory', 
      name: 'Memory Match', 
      desc: 'Match pairs of hidden symbols in record time.', 
      req: 6, 
      color: 'purple' 
    },
    { 
      id: 'pattern', 
      name: 'Pattern recognition', 
      desc: 'Follow and repeat complex light sequences.', 
      req: 9, 
      color: 'cyan' 
    }
  ];

  if (activeGame === 'math') {
    return (
      <div className="max-w-4xl mx-auto space-y-4">
        <button onClick={() => setActiveGame(null)} className="text-gray-400 hover:text-white flex items-center gap-2 transition-all">
          &larr; Back to Arcade
        </button>
        <QuickMath />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in zoom-in-95 duration-500">
      <div className="text-center md:text-left">
        <h1 className="text-3xl font-bold">Brain Gym Arcade</h1>
        <p className="text-gray-400">Sharpen your cognitive skills while earning rewards.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {games.map((game) => {
          const isUnlocked = completedTasks >= game.req;
          return (
            <div 
              key={game.id}
              className={`glass-card relative overflow-hidden group transition-all duration-500 ${!isUnlocked ? 'opacity-50 grayscale' : 'hover:scale-[1.02] cursor-pointer'}`}
              onClick={() => isUnlocked && setActiveGame(game.id)}
            >
              {!isUnlocked && (
                <div className="absolute inset-0 z-10 bg-black/40 backdrop-blur-[2px] flex flex-col items-center justify-center text-white p-6 text-center">
                  <Lock className="mb-2 text-gray-400" size={32} />
                  <p className="font-bold">LOCKED</p>
                  <p className="text-xs text-gray-300 mt-1">Complete {game.req} tasks to unlock</p>
                </div>
              )}
              
              <div className="relative z-0">
                <div className={`w-12 h-12 rounded-xl mb-4 flex items-center justify-center bg-${game.color}-500/20 text-${game.color}-400`}>
                  <Gamepad2 size={24} />
                </div>
                <h3 className="text-xl font-bold mb-2">{game.name}</h3>
                <p className="text-sm text-gray-400 mb-6">{game.desc}</p>
                
                <div className="flex items-center gap-2 font-bold text-xs">
                  <div className={`px-3 py-1.5 rounded-lg bg-${game.color}-500/10 text-${game.color}-400 flex items-center gap-1.5 uppercase tracking-wider`}>
                    <Play size={12} fill="currentColor" /> Play Now
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default GamesPage;

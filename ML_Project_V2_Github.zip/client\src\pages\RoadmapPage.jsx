import React from 'react';
import { 
  Milestone, 
  Code, 
  Briefcase, 
  Globe, 
  Terminal, 
  Cpu, 
  Award,
  ChevronRight
} from 'lucide-react';

const RoadmapPage = () => {
  const roadmapData = [
    {
      year: 'Year 1: Foundations',
      items: [
        { title: 'Master C/C++', icon: Terminal, desc: 'Learn logic building and basic syntax.' },
        { title: 'Data Structures', icon: Cpu, desc: 'Arrays, Linked Lists, Stacks, Queues.' },
        { title: 'Web Basics', icon: Globe, desc: 'HTML, CSS, JavaScript fundamentals.' }
      ]
    },
    {
      year: 'Year 2: Core Engineering',
      items: [
        { title: 'Advanced DSA', icon: Cpu, desc: 'Trees, Graphs, DP, and Algorithms.' },
        { title: 'DBMS & OS', icon: Milestone, desc: 'Understand how computers and data work.' },
        { title: 'Project 1: Full Stack', icon: Code, desc: 'Build a working web or app project.' }
      ]
    },
    {
      year: 'Year 3: Specialization',
      items: [
        { title: 'Aptitude & Soft Skills', icon: Award, desc: 'Prepare for quantitative and verbal tests.' },
        { title: 'Machine Learning / Cloud', icon: Brain, desc: 'Explore AI or Cloud Infrastructure.' },
        { title: 'Internships', icon: Briefcase, desc: 'Get hands-on industry experience.' }
      ]
    },
    {
      year: 'Year 4: Final Sprint',
      items: [
        { title: 'Placement Prep', icon: Award, desc: 'Mock interviews and problem-solving.' },
        { title: 'Capstone Project', icon: Code, desc: 'Major final year project implementation.' },
        { title: 'Job Offers', icon: Briefcase, desc: 'Technical rounds and HR interviews.' }
      ]
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-12 animate-in fade-in duration-1000">
      <div className="text-center">
        <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
          Placement Master Roadmap
        </h1>
        <p className="text-gray-400 mt-2">A step-by-step guide for CSE students to land top tier jobs.</p>
      </div>

      <div className="relative space-y-16 mt-10">
        <div className="absolute left-8 top-4 bottom-4 w-1 bg-gradient-to-b from-blue-500/50 via-purple-500/50 to-cyan-500/50 hidden md:block" />
        
        {roadmapData.map((phase, idx) => (
          <div key={idx} className="relative">
            <div className="hidden md:flex absolute left-8 -translate-x-1/2 w-4 h-4 rounded-full bg-blue-500 border-4 border-black z-10" />
            <h2 className="text-xl font-bold mb-6 ml-0 md:ml-16 text-blue-400 uppercase tracking-tighter">{phase.year}</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 ml-0 md:ml-16">
              {phase.items.map((item, i) => (
                <div key={i} className="glass-card hover:border-blue-500/30 group transition-all">
                  <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <item.icon className="text-gray-400 group-hover:text-blue-400" size={20} />
                  </div>
                  <h4 className="font-bold mb-1">{item.title}</h4>
                  <p className="text-xs text-gray-500 leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="glass-card bg-gradient-to-r from-blue-900/10 to-transparent flex items-center justify-between">
        <div>
          <h3 className="font-bold">Need Personalized Advice?</h3>
          <p className="text-sm text-gray-400">Ask our AI Coach for specific study resources.</p>
        </div>
        <ChevronRight className="text-gray-500" />
      </div>
    </div>
  );
};

// Simple Brain Icon workaround for internal use
const Brain = ({ className, size }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96.44 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 4.44-2.04" />
    <path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96.44 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-4.44-2.04" />
  </svg>
);

export default RoadmapPage;

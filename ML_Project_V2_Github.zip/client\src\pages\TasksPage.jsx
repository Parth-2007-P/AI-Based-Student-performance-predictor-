import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Circle, 
  Lock, 
  Unlock,
  Trophy,
  Zap
} from 'lucide-react';

const TasksPage = ({ user }) => {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');
  const [stats, setStats] = useState({ totalTasks: 0, completedTasks: 0, progress: 0 });

  useEffect(() => {
    if (user) {
      fetchTasks();
      fetchStats();
    }
  }, [user]);

  const fetchTasks = async () => {
    try {
      const res = await axios.get(`/api/tasks?userId=${user.id}`);
      setTasks(res.data);
    } catch (err) { console.error(err); }
  };

  const fetchStats = async () => {
    try {
      const res = await axios.get(`/api/stats?userId=${user.id}`);
      setStats(res.data);
    } catch (err) { console.error(err); }
  };

  const addTask = async (e) => {
    e.preventDefault();
    if (!newTask.trim() || !user) return;
    try {
      await axios.post('/api/tasks', { 
        userId: user.id,
        title: newTask, 
        points: 10 
      });
      setNewTask('');
      fetchTasks();
      fetchStats();
    } catch (err) { console.error(err); }
  };

  const toggleTask = async (id, completed) => {
    try {
      await axios.patch(`/api/tasks/${id}`, { completed: !completed });
      fetchTasks();
      fetchStats();
    } catch (err) { console.error(err); }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in slide-in-from-right-4 duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start gap-6">
        <div className="flex-1 w-full space-y-6">
          <div className="text-left">
            <h1 className="text-3xl font-bold">Smart Task Manager</h1>
            <p className="text-gray-400">Complete tasks to earn XP and unlock brain games.</p>
          </div>

          <form onSubmit={addTask} className="flex gap-2">
            <input
              type="text"
              value={newTask}
              onChange={(e) => setNewTask(e.target.value)}
              placeholder="Enter a new mission..."
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500/50 transition-all text-white"
            />
            <button type="submit" className="glass-button px-4 py-3 flex items-center justify-center">
              <Plus size={20} />
            </button>
          </form>

          <div className="space-y-3">
            {tasks.length === 0 ? (
              <div className="text-center py-12 glass-card border-dashed">
                <p className="text-gray-500">No active missions. Start by adding one!</p>
              </div>
            ) : (
              tasks.map((task) => (
                <div 
                  key={task._id} 
                  className={`glass-card p-4 flex items-center justify-between group transition-all ${task.completed ? 'opacity-60 grayscale' : ''}`}
                >
                  <div className="flex items-center gap-4">
                    <button onClick={() => toggleTask(task._id, task.completed)}>
                      {task.completed ? (
                        <CheckCircle2 className="text-green-500" size={24} />
                      ) : (
                        <Circle className="text-gray-600 group-hover:text-blue-500" size={24} />
                      )}
                    </button>
                    <span className={`text-lg transition-all ${task.completed ? 'line-through text-gray-500' : 'text-gray-200'}`}>
                      {task.title}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-yellow-500 bg-yellow-500/10 px-2 py-1 rounded-md">+{task.points} XP</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="w-full md:w-80 space-y-6">
           {/* XP Progress Card */}
           <div className="glass-card bg-gradient-to-br from-blue-900/20 to-purple-900/20">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-blue-500/10 rounded-lg text-blue-400">
                <Trophy size={20} />
              </div>
              <h3 className="font-bold">Next Unlock</h3>
            </div>
            
            <div className="space-y-4">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Game Unlock Progress</span>
                <span className="font-bold">{Math.round(stats.progress)}%</span>
              </div>
              <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-1000" 
                  style={{ width: `${stats.progress}%` }} 
                />
              </div>
              <p className="text-xs text-gray-500 italic text-center">
                {stats.completedTasks} / {Math.ceil((stats.completedTasks + 1) / 3) * 3} tasks for next game
              </p>
            </div>
          </div>

          <div className="glass-card">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <Zap size={18} className="text-yellow-500" /> Unlock Status
            </h3>
            <div className="space-y-3">
              {[
                { name: 'Quick Math', icon: Unlock, unlocked: stats.completedTasks >= 3 },
                { name: 'Memory Match', icon: stats.completedTasks >= 6 ? Unlock : Lock, unlocked: stats.completedTasks >= 6 },
                { name: 'Pattern Guru', icon: stats.completedTasks >= 9 ? Unlock : Lock, unlocked: stats.completedTasks >= 9 }
              ].map((game, i) => (
                <div key={i} className={`flex items-center justify-between p-3 rounded-xl border ${game.unlocked ? 'bg-green-500/5 border-green-500/20 text-green-400' : 'bg-white/5 border-white/5 text-gray-500'}`}>
                  <span className="text-sm font-medium">{game.name}</span>
                  <game.icon size={16} />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TasksPage;

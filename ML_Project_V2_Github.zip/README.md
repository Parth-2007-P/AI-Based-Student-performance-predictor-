# AI-Powered Student Performance Predictor & Productivity System

A modern, high-end productivity platform for students featuring AI-driven performance analytics, gamified productivity tools, and mental wellness support.

## 🚀 Getting Started

### 1. ML Service (Python)
The ML microservice handles Random Forest predictions for Marks and Grades.
```bash
cd ml_service
pip install pandas scikit-learn flask flask-cors
python generate_data.py  # Reset/Generate dataset
python train_ml.py     # Train models
python app.py          # Start Flask server (Port 5000)
```

### 2. Backend API (Node.js)
The core backend handles database operations for tasks and predictions.
```bash
cd server
npm install
# Ensure MongoDB is running locally on port 27017
node server.js         # Start Express server (Port 5001)
```

### 3. Frontend Dashboard (React)
The premium UI with glassmorphism and real-time charts.
```bash
cd client
npm install
npm run dev            # Start Vite server (Port 5173)
```

## 🛠 Features Included
- **AI Prediction**: Marks and Grade forecasting using Random Forest models.
- **Smart Tasks**: Gamified task manager that unlocks rewards.
- **Brain Gym**: Fully playable "Quick Math" game (Unlocks after 3 tasks).
- **AI Coach**: Cyberpunk chatbot with stress detection logic.
- **Master Roadmap**: Comprehensive placement guide for CSE students.
- **PDF Analysis**: Professional report generation with downloadable PDF.

## 🎨 UI/UX Theme
- **Theme**: Dark Mode (Cyberpunk Minimalist)
- **Colors**: Deep Navy, Electric Blue, Neon Purple
- **Design**: Glassmorphism cards with backdrop blur and smooth transitions.

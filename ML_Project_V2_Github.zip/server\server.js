const express = require('express');
const cors = require('cors');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5001;
const ML_URI = process.env.ML_URI || 'http://localhost:5000';
const JWT_SECRET = process.env.JWT_SECRET || 'aether_secret_key_123';
const DB_FILE = path.join(__dirname, 'db.json');

app.use(cors());
app.use(express.json());

// Simple JSON DB Initialization
if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify({ users: [], tasks: [], performance: [] }, null, 2));
}

const getData = () => {
    try {
        const content = fs.readFileSync(DB_FILE, 'utf8');
        console.log('DB Read successful, content length:', content.length);
        return JSON.parse(content);
    } catch (err) {
        console.error('DB Read Error:', err);
        return { users: [], tasks: [], performance: [] };
    }
};

const saveData = (data) => {
    try {
        fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
        console.log('DB Save successful');
    } catch (err) {
        console.error('DB Save Error:', err);
    }
};

// API Routes
app.get('/ping', (req, res) => res.send('pong'));

// 0. Auth Routes
app.post('/api/auth/register', async (req, res) => {
    console.log('>>> Register attempt for:', req.body.email);
    try {
        const { name, email, password } = req.body;
        const db = getData();
        
        if (db.users.find(u => u.email === email)) {
            return res.status(400).json({ error: 'Email already exists' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = { id: Date.now().toString(), name, email, password: hashedPassword };
        db.users.push(newUser);
        saveData(db);

        const token = jwt.sign({ userId: newUser.id }, JWT_SECRET);
        res.json({ token, user: { name, email, id: newUser.id } });
    } catch (err) {
        console.error('Register error:', err);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const db = getData();
        const user = db.users.find(u => u.email === email);
        
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const token = jwt.sign({ userId: user.id }, JWT_SECRET);
        res.json({ token, user: { name: user.name, email, id: user.id } });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// 1. ML Prediction Proxy
app.post('/api/predict', async (req, res) => {
    try {
        const response = await axios.post(`${ML_URI}/predict`, req.body);
        const prediction = response.data;
        const db = getData();

        // Save to DB
        const perf = {
            id: Date.now().toString(),
            userId: req.body.userId || 'anonymous',
            ...req.body,
            prediction: {
                marks: prediction.predicted_marks,
                grade: prediction.predicted_grade,
                risk: prediction.risk_level,
                confidence: prediction.confidence_score
            },
            createdAt: new Date().toISOString()
        };
        db.performance.push(perf);
        saveData(db);

        res.json(prediction);
    } catch (error) {
        console.error('Prediction error:', error.message);
        res.status(500).json({ error: 'Failed to get prediction from ML service' });
    }
});

// 2. Performance History
app.get('/api/history', (req, res) => {
    try {
        const db = getData();
        const userId = req.query.userId;
        const history = db.performance
            .filter(p => !userId || p.userId === userId)
            .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
            .slice(0, 5);
        res.json(history);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// 3. Tasks
app.get('/api/tasks', (req, res) => {
    const db = getData();
    const userId = req.query.userId;
    const tasks = db.tasks.filter(t => !userId || t.userId === userId);
    res.json(tasks);
});

app.post('/api/tasks', (req, res) => {
    const db = getData();
    const task = { id: Date.now().toString(), ...req.body, completed: false };
    db.tasks.push(task);
    saveData(db);
    res.json(task);
});

app.patch('/api/tasks/:id', (req, res) => {
    const db = getData();
    const index = db.tasks.findIndex(t => t.id === req.params.id);
    if (index !== -1) {
        db.tasks[index] = { ...db.tasks[index], ...req.body };
        saveData(db);
        res.json(db.tasks[index]);
    } else {
        res.status(404).json({ error: 'Task not found' });
    }
});

// 4. Game Unlock Stats
app.get('/api/stats', (req, res) => {
    const db = getData();
    const userId = req.query.userId;
    const userTasks = db.tasks.filter(t => !userId || t.userId === userId);
    const totalTasks = userTasks.length;
    const completedTasks = userTasks.filter(t => t.completed).length;
    res.json({ totalTasks, completedTasks, progress: totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0 });
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log('Running with local JSON database (db.json)');
});

// AetherNode V2.2 - Neural Logic
let currentUser = JSON.parse(localStorage.getItem('user')) || null;
let activeTab = 'dashboard';
let isSignup = false;

// --- Initialize ---
document.addEventListener('DOMContentLoaded', () => {
    if (currentUser) {
        showDashboard();
    } else {
        showAuth();
    }
    updateDate();
});

function updateDate() {
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    document.getElementById('today-date').innerText = new Date().toLocaleDateString('en-US', options);
}

// --- Auth Functions ---
function switchAuth(type) {
    isSignup = type === 'signup';
    document.getElementById('login-tab').classList.toggle('active', !isSignup);
    document.getElementById('signup-tab').classList.toggle('active', isSignup);
    document.getElementById('name-field').classList.toggle('hidden', !isSignup);
    document.getElementById('auth-submit').innerText = isSignup ? 'Create Agent' : 'Initialize Session';
}

async function handleAuth(e) {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const name = document.getElementById('name').value;
    const errorEl = document.getElementById('auth-error');
    
    errorEl.innerText = '';
    const endpoint = isSignup ? '/api/auth/register' : '/api/auth/login';
    const payload = isSignup ? { name, email, password } : { email, password };

    try {
        const res = await axios.post(endpoint, payload);
        currentUser = res.data.user;
        localStorage.setItem('token', res.data.token);
        localStorage.setItem('user', JSON.stringify(currentUser));
        showDashboard();
    } catch (err) {
        errorEl.innerText = err.response?.data?.error || 'Authentication Failed';
    }
}

function handleLogout() {
    localStorage.clear();
    location.reload();
}

// --- Navigation ---
function showDashboard() {
    document.getElementById('auth-section').classList.add('hidden');
    document.getElementById('main-section').classList.remove('hidden');
    document.getElementById('welcome-msg').innerText = `Welcome, ${currentUser.name}`;
    loadStats();
    loadHistory();
}

function showAuth() {
    document.getElementById('auth-section').classList.remove('hidden');
    document.getElementById('main-section').classList.add('hidden');
}

function switchTab(tabId) {
    activeTab = tabId;
    document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('.nav-btn').forEach(el => el.classList.remove('active'));
    
    document.getElementById(`tab-${tabId}`).classList.remove('hidden');
    event.currentTarget.classList.add('active');

    if (tabId === 'tasks') loadTasks();
    if (tabId === 'dashboard') { loadStats(); loadHistory(); }
}

// --- Task Functions ---
async function loadTasks() {
    try {
        const res = await axios.get(`/api/tasks?userId=${currentUser.id}`);
        const list = document.getElementById('tasks-list');
        list.innerHTML = res.data.map(task => `
            <div class="task-item ${task.completed ? 'completed' : ''}">
                <div class="checkbox ${task.completed ? 'checked' : ''}" onclick="toggleTask('${task.id}', ${task.completed})"></div>
                <span>${task.title}</span>
            </div>
        `).join('');
    } catch (err) { console.error(err); }
}

async function addTask(e) {
    e.preventDefault();
    const input = document.getElementById('task-input');
    if (!input.value.trim()) return;

    try {
        await axios.post('/api/tasks', { 
            userId: currentUser.id, 
            title: input.value,
            points: 10
        });
        input.value = '';
        loadTasks();
    } catch (err) { console.error(err); }
}

async function toggleTask(id, currentStatus) {
    try {
        await axios.patch(`/api/tasks/${id}`, { completed: !currentStatus });
        loadTasks();
    } catch (err) { console.error(err); }
}

// --- Prediction Functions ---
async function runPrediction(e) {
    e.preventDefault();
    const btn = document.getElementById('predict-submit');
    const resultBox = document.getElementById('prediction-result');
    
    btn.disabled = true;
    btn.innerText = 'Calculating Neural Map...';

    const data = {
        userId: currentUser.id,
        study_hours: parseFloat(document.getElementById('study_hours').value),
        attendance: parseFloat(document.getElementById('attendance').value),
        internal_marks: parseFloat(document.getElementById('internal_marks').value),
        mock_score: parseFloat(document.getElementById('mock_score').value)
    };

    try {
        const res = await axios.post('/api/predict', data);
        resultBox.classList.remove('hidden');
        resultBox.innerHTML = `
            <div class="result-grid">
                <div class="glass">
                    <p class="text-secondary text-sm">Predicted Grade</p>
                    <h2 class="text-3xl font-bold text-accent-purple">${res.data.predicted_grade}</h2>
                </div>
                <div class="glass">
                    <p class="text-secondary text-sm">Target Score</p>
                    <h2 class="text-3xl font-bold text-accent-blue">${res.data.predicted_marks}%</h2>
                </div>
                <div class="glass">
                    <p class="text-secondary text-sm">Risk Level</p>
                    <h2 class="text-xl font-bold">${res.data.risk_level}</h2>
                </div>
            </div>
        `;
    } catch (err) {
        alert('ML Microservice Unreachable. Please ensure app.py is running.');
    } finally {
        btn.disabled = false;
        btn.innerText = 'Generate Forecast';
    }
}

// --- Dashboard Stats ---
async function loadStats() {
    try {
        const res = await axios.get(`/api/stats?userId=${currentUser.id}`);
        const circle = document.getElementById('score-circle');
        const text = document.getElementById('score-text');
        
        const progress = Math.round(res.data.progress || 0);
        circle.style.strokeDasharray = `${progress}, 100`;
        text.textContent = `${progress}%`;
    } catch (err) { console.error(err); }
}

async function loadHistory() {
    try {
        const res = await axios.get(`/api/history?userId=${currentUser.id}`);
        const list = document.getElementById('history-list');
        list.innerHTML = res.data.length ? res.data.map(item => `
            <div class="task-item">
                <div class="flex-1">
                    <p class="text-sm">Grade: ${item.prediction.grade}</p>
                    <p class="text-[10px] text-secondary">${new Date(item.createdAt).toLocaleDateString()}</p>
                </div>
            </div>
        `).join('') : '<p class="text-secondary text-center py-4">No previous scans found</p>';
    } catch (err) { console.error(err); }
}

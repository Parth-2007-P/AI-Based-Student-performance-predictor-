import React, { useState } from 'react';
import axios from 'axios';
import { 
  Send, 
  Loader2, 
  CheckCircle,
  HelpCircle,
  AlertTriangle
} from 'lucide-react';

const InputField = ({ label, name, type = "number", value, onChange, min, max, step = "1", help }) => (
  <div className="space-y-2">
    <div className="flex items-center gap-2">
      <label className="text-sm font-medium text-gray-300">{label}</label>
      {help && (
        <div className="group relative">
          <HelpCircle size={14} className="text-gray-500 cursor-help" />
          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-2 bg-gray-900 text-[10px] rounded-lg opacity-0 group-hover:opacity-100 transition-all pointer-events-none border border-white/10 shadow-xl z-50 text-white">
            {help}
          </div>
        </div>
      )}
    </div>
    <input
      type={type}
      name={name}
      value={value}
      onChange={onChange}
      min={min}
      max={max}
      step={step}
      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500/50 transition-all text-white placeholder:text-gray-600"
      required
    />
  </div>
);

const PredictPage = ({ user, setPredictionResult, setActiveTab }) => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    userId: user?.id || 'anonymous',
    study_hours: 6,
    attendance: 85,
    internal_marks: 20,
    assignment_score: 15,
    sleep_hours: 7,
    stress_level: 5,
    prev_grade: 8,
    study_consistency: 5,
    mock_score: 75,
    backlogs: 0
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: parseFloat(value) }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      // Simulate processing time for UX
      await new Promise(r => setTimeout(r, 1500));
      const res = await axios.post('/api/predict', { ...formData, userId: user?.id });
      setPredictionResult(res.data);
      setActiveTab('dashboard');
    } catch (err) {
      console.error(err);
      alert('Prediction failed. Ensure Backend and ML services are running.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-2">Academic Intelligence Forecast</h1>
        <p className="text-gray-400">Provide your data for AI-driven performance mapping.</p>
      </div>

      <div className="glass-card">
        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <InputField 
              label="Study Hours / Day" 
              name="study_hours" 
              value={formData.study_hours} 
              onChange={handleChange} 
              min="0" max="24" step="0.5"
              help="Average hours spent studying outside classes."
            />
            <InputField 
              label="Attendance (%)" 
              name="attendance" 
              value={formData.attendance} 
              onChange={handleChange} 
              min="0" max="100"
              help="Percentage of classes attended this semester."
            />
            <InputField 
              label="Internal Marks (out of 30)" 
              name="internal_marks" 
              value={formData.internal_marks} 
              onChange={handleChange} 
              min="0" max="30"
              help="Average of your mid-term or internal assessments."
            />
            <InputField 
              label="Assignment Score (out of 20)" 
              name="assignment_score" 
              value={formData.assignment_score} 
              onChange={handleChange} 
              min="0" max="20"
              help="Points earned from assignments and classwork."
            />
            <InputField 
              label="Sleep Hours" 
              name="sleep_hours" 
              value={formData.sleep_hours} 
              onChange={handleChange} 
              min="0" max="24"
              help="Average sleep hours per night."
            />
            <InputField 
              label="Stress Level (1-10)" 
              name="stress_level" 
              value={formData.stress_level} 
              onChange={handleChange} 
              min="1" max="10"
              help="1 being calm, 10 being extremely stressed."
            />
            <InputField 
              label="Prev Semester Grade (CGPA)" 
              name="prev_grade" 
              value={formData.prev_grade} 
              onChange={handleChange} 
              min="0" max="10" step="0.1"
            />
            <InputField 
              label="Study Consistency (days/week)" 
              name="study_consistency" 
              value={formData.study_consistency} 
              onChange={handleChange} 
              min="0" max="7"
            />
            <InputField 
              label="Mock Test Score (%)" 
              name="mock_score" 
              value={formData.mock_score} 
              onChange={handleChange} 
              min="0" max="100"
            />
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-300">Any Backlogs?</label>
              <select 
                name="backlogs"
                value={formData.backlogs}
                onChange={handleChange}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500/50 transition-all text-white"
              >
                <option value="0" className="bg-[#0a0a0c]">No Backlogs</option>
                <option value="1" className="bg-[#0a0a0c]">Existing Backlogs</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between pt-6 border-t border-white/5">
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <CheckCircle size={14} className="text-green-500" />
              All inputs are processed by Random Forest microservice.
            </div>
            <button 
              type="submit" 
              disabled={loading}
              className="glass-button flex items-center gap-2 min-w-[200px] justify-center"
            >
              {loading ? (
                <>
                  <Loader2 size={18} className="animate-spin" /> Processing...
                </>
              ) : (
                <>
                  Generate Forecast <Send size={18} />
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PredictPage;

import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Bot, 
  User, 
  Sparkles, 
  RefreshCcw,
  Brain
} from 'lucide-react';

const ChatbotPage = () => {
  const [messages, setMessages] = useState([
    { 
      id: 1, 
      text: "Hello! I'm your AetherNode AI Coach. How are you feeling about your studies today?", 
      sender: 'bot',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMsg = {
      id: Date.now(),
      text: input,
      sender: 'user',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    // AI Logic (Simple keyword based for 1st year project scope)
    setTimeout(() => {
      let botResponse = "";
      const lowerInput = input.toLowerCase();

      if (lowerInput.includes('stress') || lowerInput.includes('anxious') || lowerInput.includes('tired')) {
        botResponse = "I detect some stress in your words. Take a deep breath. Have you tried the 'Quick Math' game in our Arcade? It helps shift focus. Also, ensure you're getting at least 7 hours of sleep!";
      } else if (lowerInput.includes('exam') || lowerInput.includes('test') || lowerInput.includes('marks')) {
        botResponse = "Exams can be tough! Focus on active recall and spaced repetition. Your current AI prediction shows a good trend, just keep the consistency above 5 days/week.";
      } else if (lowerInput.includes('career') || lowerInput.includes('job') || lowerInput.includes('placement')) {
        botResponse = "Thinking about the future! Check out the 'Career Map' tab for a step-by-step placement roadmap tailored for CSE students.";
      } else {
        botResponse = "That's interesting! Remember, consistency is the key to academic success. Is there anything specific about your subjects you want to discuss?";
      }

      const botMsg = {
        id: Date.now() + 1,
        text: botResponse,
        sender: 'bot',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, botMsg]);
      setIsTyping(false);
    }, 1000);
  };

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-160px)] flex flex-col space-y-4 animate-in fade-in duration-700">
      <div className="flex items-center justify-between px-2">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Brain className="text-purple-500" /> AI Student Coach
          </h1>
          <p className="text-xs text-gray-500 uppercase tracking-widest font-bold">Neural Engine v1.0</p>
        </div>
        <button onClick={() => setMessages([messages[0]])} className="p-2 hover:bg-white/5 rounded-lg text-gray-500 hover:text-white transition-all">
          <RefreshCcw size={18} />
        </button>
      </div>

      <div className="flex-1 glass-card overflow-hidden flex flex-col p-0 border-white/10">
        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2`}>
              <div className={`flex gap-3 max-w-[80%] ${msg.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${msg.sender === 'user' ? 'bg-blue-600' : 'bg-purple-600'}`}>
                  {msg.sender === 'user' ? <User size={16} /> : <Bot size={16} />}
                </div>
                <div>
                  <div className={`p-4 rounded-2xl ${msg.sender === 'user' ? 'bg-blue-600 text-white rounded-tr-none' : 'bg-white/5 border border-white/10 text-gray-200 rounded-tl-none'}`}>
                    <p className="text-sm leading-relaxed">{msg.text}</p>
                  </div>
                  <p className={`text-[10px] mt-1 text-gray-500 ${msg.sender === 'user' ? 'text-right' : 'text-left'}`}>{msg.time}</p>
                </div>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start animate-pulse">
              <div className="flex gap-3 items-center">
                <div className="w-8 h-8 rounded-lg bg-purple-600 flex items-center justify-center">
                  <Bot size={16} />
                </div>
                <div className="flex gap-1">
                  <div className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce" />
                  <div className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <div className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce [animation-delay:0.4s]" />
                </div>
              </div>
            </div>
          )}
          <div ref={scrollRef} />
        </div>

        {/* Input Area */}
        <form onSubmit={handleSend} className="p-4 bg-white/5 border-t border-white/10 flex gap-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your message here..."
            className="flex-1 bg-transparent border-none outline-none text-sm placeholder:text-gray-600"
          />
          <button type="submit" className="p-3 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl hover:opacity-90 transition-all active:scale-95">
            <Send size={18} />
          </button>
        </form>
      </div>
      
      <div className="grid grid-cols-3 gap-3">
        {['Academic Advice', 'Stress Relief', 'Career Planning'].map(q => (
          <button 
            key={q}
            onClick={() => setInput(q)}
            className="glass-card py-2 px-3 text-[10px] font-bold uppercase tracking-wider text-gray-400 hover:text-white hover:border-blue-500/50 transition-all"
          >
            {q}
          </button>
        ))}
      </div>
    </div>
  );
};

export default ChatbotPage;

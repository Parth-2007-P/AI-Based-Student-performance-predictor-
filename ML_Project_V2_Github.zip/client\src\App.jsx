import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  BarChart3, 
  LayoutDashboard, 
  BrainCircuit, 
  ListTodo, 
  Gamepad2, 
  MessageSquareText, 
  FileText, 
  Map, 
  Settings,
  X,
  Menu,
  LogOut
} from 'lucide-react';
import Dashboard from './pages/Dashboard';
import PredictPage from './pages/PredictPage';
import TasksPage from './pages/TasksPage';
import GamesPage from './pages/GamesPage';
import ChatbotPage from './pages/ChatbotPage';
import ReportPage from './pages/ReportPage';
import RoadmapPage from './pages/RoadmapPage';
import AuthPage from './pages/AuthPage';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [predictionResult, setPredictionResult] = useState(null);
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('user')) || null);

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'predict', label: 'AI Prediction', icon: BrainCircuit },
    { id: 'tasks', label: 'Tasks & Tasks', icon: ListTodo },
    { id: 'games', label: 'Brain Gym', icon: Gamepad2 },
    { id: 'chatbot', label: 'AI Chatbot', icon: MessageSquareText },
    { id: 'roadmap', label: 'Career Map', icon: Map },
    { id: 'report', label: 'Report', icon: FileText },
  ];

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard predictionResult={predictionResult} setActiveTab={setActiveTab} />;
      case 'predict': return <PredictPage setPredictionResult={setPredictionResult} setActiveTab={setActiveTab} />;
      case 'tasks': return <TasksPage user={user} />;
      case 'games': return <GamesPage />;
      case 'chatbot': return <ChatbotPage />;
      case 'roadmap': return <RoadmapPage />;
      case 'report': return <ReportPage predictionResult={predictionResult} />;
      default: return <Dashboard />;
    }
  };

  if (!user) {
    return <AuthPage onLogin={(userData) => setUser(userData)} />;
  }

  return (
    <div className="flex h-screen bg-[#0a0a0c] text-white font-['Inter'] overflow-hidden">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-20'} bg-[rgba(23,23,27,0.7)] backdrop-blur-xl border-r border-white/5 transition-all duration-300 flex flex-col`}>
        <div className="p-6 flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
            <BarChart3 size={18} />
          </div>
          {sidebarOpen && <span className="font-bold text-xl bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">AetherNode</span>}
        </div>

        <nav className="flex-1 px-4 mt-4 space-y-2">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                activeTab === item.id 
                  ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <item.icon size={20} />
              {sidebarOpen && <span className="font-medium">{item.label}</span>}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5 space-y-2">
          <button className="w-full flex items-center gap-3 px-4 py-3 text-gray-400 hover:text-white transition-all">
            <Settings size={20} />
            {sidebarOpen && <span>Settings</span>}
          </button>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 text-red-400 hover:text-red-300 transition-all"
          >
            <LogOut size={20} />
            {sidebarOpen && <span>Logout</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 border-b border-white/5 flex items-center justify-between px-8 bg-[#0a0a0c]/50 backdrop-blur-sm">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 hover:bg-white/5 rounded-lg transition-all">
            <Menu size={20} />
          </button>
          
          <div className="flex items-center gap-4">
            <div className="text-right mr-4 hidden md:block">
              <p className="text-sm font-semibold">{user.name}</p>
              <p className="text-xs text-gray-500">{user.email}</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-blue-400 to-purple-500 border-2 border-white/10 flex items-center justify-center font-bold">
               {user.name.charAt(0)}
            </div>
          </div>
        </header>

        <section className="flex-1 overflow-y-auto p-8 custom-scrollbar">
          {renderContent()}
        </section>
      </main>
    </div>
  );
}

export default App;

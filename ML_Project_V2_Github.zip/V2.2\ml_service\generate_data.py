import pandas as pd
import numpy as np
import random

def generate_dataset(n=150):
    data = []
    for _ in range(n):
        study_hours = round(random.uniform(2, 12), 1)
        attendance = round(random.uniform(60, 100), 1)
        internal_marks = round(random.uniform(10, 30), 1)
        assignment_score = round(random.uniform(5, 20), 1)
        sleep_hours = round(random.uniform(4, 9), 1)
        stress_level = random.randint(1, 10)
        prev_grade = random.choice([6, 7, 8, 9, 10]) # simplified GPA points
        study_consistency = random.randint(3, 7)
        mock_score = round(random.uniform(30, 95), 1)
        backlogs = 1 if random.random() > 0.8 else 0
        
        # Logic for Final Marks (weighted calculation with some noise)
        base_marks = (study_hours * 3) + (attendance * 0.2) + (internal_marks * 1) + (assignment_score * 0.5) + (mock_score * 0.2)
        noise = random.uniform(-5, 5)
        final_marks = min(100, max(0, round(base_marks + noise, 1)))
        
        # Logic for Final Grade
        if final_marks >= 85: grade = 'A'
        elif final_marks >= 70: grade = 'B'
        elif final_marks >= 50: grade = 'C'
        else: grade = 'D'
        
        data.append([
            study_hours, attendance, internal_marks, assignment_score,
            sleep_hours, stress_level, prev_grade, study_consistency,
            mock_score, backlogs, final_marks, grade
        ])
    
    columns = [
        'Study Hours', 'Attendance (%)', 'Internal Marks', 'Assignment Score',
        'Sleep Hours', 'Stress Level', 'Prev Sem Grade', 'Study Consistency',
        'Mock Test Score', 'Backlogs', 'Final Marks', 'Final Grade'
    ]
    
    df = pd.DataFrame(data, columns=columns)
    df.to_csv('dataset.csv', index=False)
    print("Dataset generated: dataset.csv with 150 rows.")

if __name__ == "__main__":
    generate_dataset()

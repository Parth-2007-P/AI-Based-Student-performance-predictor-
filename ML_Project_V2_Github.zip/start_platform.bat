@echo off
echo Starting AetherNode Platform...

echo Starting ML Service...
start cmd /k "cd ml_service && python app.py"

echo Starting Backend Server...
start cmd /k "cd server && node server.js"

echo Starting Frontend...
start cmd /k "cd client && npm run dev"

echo All services are launching in separate windows.
echo Please visit http://localhost:5173 once the frontend is ready.

import pandas as pd
import pickle
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.metrics import mean_absolute_error, accuracy_score
from sklearn.preprocessing import LabelEncoder

def train_with_real_data():
    # Load dataset
    df = pd.read_csv('../../StudentPerformanceFactors.csv')
    
    # Preprocessing
    # Specify categorical columns correctly based on dataset inspection
    categorical_cols = [
        'Parental_Involvement', 'Access_to_Resources', 'Extracurricular_Activities',
        'Motivation_Level', 'Internet_Access', 'Family_Income',
        'Teacher_Quality', 'School_Type', 'Peer_Influence', 'Physical_Activity',
        'Learning_Disabilities', 'Parental_Education_Level', 'Distance_from_Home', 'Gender'
    ]
    
    label_encoders = {}
    for col in categorical_cols:
        if col in df.columns:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col].astype(str))
            label_encoders[col] = le
        else:
            print(f"Warning: Column {col} not found in dataset.")
        
    # Handling missing values
    df = df.fillna(df.median(numeric_only=True))

    # Target: Exam_Score
    # Derive "Final Grade" from Exam_Score for the Classifier
    def get_grade(score):
        if score >= 85: return 'A'
        elif score >= 70: return 'B'
        elif score >= 50: return 'C'
        else: return 'D'
    
    df['Final_Grade'] = df['Exam_Score'].apply(get_grade)

    # Features (all columns except targets)
    X = df.drop(['Exam_Score', 'Final_Grade'], axis=1)
    y_marks = df['Exam_Score']
    y_grade = df['Final_Grade']
    
    # Split
    X_train, X_test, y_marks_train, y_marks_test, y_grade_train, y_grade_test = train_test_split(
        X, y_marks, y_grade, test_size=0.2, random_state=42
    )
    
    # 1. Marks Prediction Model (Regression)
    regressor = RandomForestRegressor(n_estimators=10, random_state=42)
    regressor.fit(X_train, y_marks_train)
    marks_preds = regressor.predict(X_test)
    print(f"Real Data Marks Model MAE: {mean_absolute_error(y_marks_test, marks_preds):.2f}")
    
    # 2. Grade Prediction Model (Classification)
    classifier = RandomForestClassifier(n_estimators=10, random_state=42)
    classifier.fit(X_train, y_grade_train)
    grade_preds = classifier.predict(X_test)
    print(f"Real Data Grade Model Accuracy: {accuracy_score(y_grade_test, grade_preds) * 100:.2f}%")
    
    # Save Models, Encoders, and Feature List
    with open('marks_model.pkl', 'wb') as f:
        pickle.dump(regressor, f)
    with open('grade_model.pkl', 'wb') as f:
        pickle.dump(classifier, f)
    with open('encoders.pkl', 'wb') as f:
        pickle.dump(label_encoders, f)
    with open('features.pkl', 'wb') as f:
        pickle.dump(X.columns.tolist(), f)
        
    print("Models, Encoders, and Features saved successfully.")

if __name__ == "__main__":
    train_with_real_data()

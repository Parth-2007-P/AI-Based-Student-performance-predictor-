import React, { useRef } from 'react';
import { 
  Download, 
  FileText, 
  ShieldCheck, 
  AlertCircle,
  BarChart,
  User,
  Activity
} from 'lucide-react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

const ReportPage = ({ predictionResult }) => {
  const reportRef = useRef();

  const downloadPDF = async () => {
    const element = reportRef.current;
    const canvas = await html2canvas(element, {
      backgroundColor: '#0a0a0c',
      scale: 2
    });
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save('AetherNode_Analysis_Report.pdf');
  };

  if (!predictionResult) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] space-y-4">
        <div className="p-6 rounded-full bg-white/5 border border-white/5 animate-pulse">
          <FileText size={48} className="text-gray-600" />
        </div>
        <h2 className="text-xl font-bold">No Data Available</h2>
        <p className="text-gray-400 text-center max-w-md"> Please complete an AI Prediction to generate your detailed academic performance analysis report.</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in mt-20">
      <div className="flex justify-between items-center px-2">
        <h1 className="text-2xl font-bold">Final Analysis Report</h1>
        <button 
          onClick={downloadPDF}
          className="glass-button flex items-center gap-2 text-sm"
        >
          <Download size={18} /> Download PDF
        </button>
      </div>

      <div 
        ref={reportRef}
        className="glass-card bg-[#0a0a0c] p-10 border-white/10 space-y-10"
      >
        {/* Header */}
        <div className="flex justify-between items-start border-b border-white/10 pb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
                <Activity size={18} />
              </div>
              <span className="text-xl font-bold tracking-tighter uppercase">AetherNode AI</span>
            </div>
            <p className="text-xs text-gray-500 uppercase tracking-widest font-bold">Neural Academic Forecaster</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-500 font-bold uppercase">Report ID: #AN-{Math.floor(Math.random() * 900000 + 100000)}</p>
            <p className="text-xs text-gray-500 font-bold uppercase">Generated: {new Date().toLocaleDateString()}</p>
          </div>
        </div>

        {/* Main Analysis */}
        <div className="grid grid-cols-2 gap-8">
          <div className="p-6 rounded-2xl bg-white/5 border border-white/5">
            <p className="text-xs text-gray-500 font-bold uppercase mb-4">Predicted Outcome</p>
            <div className="flex items-end gap-2 mb-2">
              <h2 className="text-5xl font-black text-blue-500">{predictionResult.predicted_marks}</h2>
              <span className="text-gray-500 mb-2 font-bold">/ 100</span>
            </div>
            <p className="text-sm font-semibold">Predicted Final Marks</p>
          </div>
          
          <div className="p-6 rounded-2xl bg-white/5 border border-white/5">
            <p className="text-xs text-gray-500 font-bold uppercase mb-4">Grade Forecast</p>
            <h2 className="text-5xl font-black text-purple-500">{predictionResult.predicted_grade}</h2>
            <p className="text-sm font-semibold mt-2">Predicted Final Grade</p>
          </div>
        </div>

        {/* Risk Assessment */}
        <div className="p-8 rounded-2xl bg-white/5 border border-white/5 relative overflow-hidden">
          <div className={`absolute top-0 right-0 px-4 py-1 text-[10px] font-bold uppercase ${predictionResult.risk_level === 'High' ? 'bg-red-500' : 'bg-green-500'}`}>
            {predictionResult.risk_level} Risk
          </div>
          <div className="flex items-start gap-4">
            <div className={`p-3 rounded-xl bg-opacity-10 ${predictionResult.risk_level === 'High' ? 'bg-red-500 text-red-400' : 'bg-green-500 text-green-400'}`}>
              {predictionResult.risk_level === 'High' ? <AlertCircle size={24} /> : <ShieldCheck size={24} />}
            </div>
            <div>
              <h3 className="text-lg font-bold mb-1">Academic Risk Assessment</h3>
              <p className="text-sm text-gray-400 leading-relaxed">
                {predictionResult.risk_level === 'High' 
                  ? "Our AI models suggest a significant risk of academic underperformance. Urgent intervention in study habits and attendance is recommended."
                  : "Performance is stable. Our AI models indicate a strong trajectory towards the predicted goals. Maintain current consistency for optimal results."}
              </p>
            </div>
          </div>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'Confidence Score', val: `${predictionResult.confidence_score}%`, color: 'text-blue-400' },
            { label: 'Stress Impact', val: 'Moderate', color: 'text-yellow-400' },
            { label: 'Consistency', val: 'High', color: 'text-green-400' },
            { label: 'Status', val: 'Verified', color: 'text-cyan-400' }
          ].map(m => (
            <div key={m.label} className="p-4 rounded-xl bg-white/5 border border-white/5 text-center">
              <p className="text-[10px] text-gray-500 font-bold uppercase mb-1">{m.label}</p>
              <p className={`text-lg font-black ${m.color}`}>{m.val}</p>
            </div>
          ))}
        </div>

        {/* Improvement Suggestions */}
        <div className="space-y-4">
          <h3 className="text-lg font-bold flex items-center gap-2">
            <BarChart size={20} className="text-blue-500" /> Improvement Roadmap
          </h3>
          <ul className="space-y-3">
            {[
              "Increase study hours by 1.5h daily to improve conceptual clarity.",
              "Focus on mock tests to boost confidence in examination patterns.",
              "Maintain attendance above 85% to ensure full internal marks.",
              "Utilize the AI Chatbot for stress relief during peak study weeks."
            ].map((text, i) => (
              <li key={i} className="flex gap-3 text-sm text-gray-400 bg-white/5 p-3 rounded-xl">
                <span className="text-blue-500 font-bold">{i+1}.</span> {text}
              </li>
            ))}
          </ul>
        </div>

        <div className="border-t border-white/10 pt-8 flex justify-between items-center opacity-50">
          <div className="text-[10px] text-gray-500 font-bold uppercase">
            &copy; 2026 AetherNode Systems - Powered by Random Forest AI
          </div>
          <div className="flex gap-4">
             <User size={14} />
             <Activity size={14} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReportPage;

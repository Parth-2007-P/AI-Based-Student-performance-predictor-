import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  TrendingUp, 
  Users, 
  Brain, 
  Zap, 
  CheckCircle2, 
  AlertTriangle,
  Clock,
  ArrowRight
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';

const data = [
  { name: 'Mon', study: 4, mock: 65 },
  { name: 'Tue', study: 6, mock: 70 },
  { name: 'Wed', study: 5, mock: 68 },
  { name: 'Thu', study: 8, mock: 75 },
  { name: 'Fri', study: 7, mock: 82 },
  { name: 'Sat', study: 9, mock: 88 },
  { name: 'Sun', study: 6, mock: 85 },
];

const StatCard = ({ title, value, subtext, icon: Icon, color }) => (
  <div className="glass-card flex items-start justify-between">
    <div>
      <p className="text-gray-400 text-sm mb-1">{title}</p>
      <h3 className="text-2xl font-bold">{value}</h3>
      <p className={`text-xs mt-1 ${color}`}>{subtext}</p>
    </div>
    <div className={`p-3 rounded-xl bg-opacity-10 bg-white`}>
      <Icon className={color} size={24} />
    </div>
  </div>
);

const Dashboard = ({ user, predictionResult, setActiveTab }) => {
  const [stats, setStats] = useState({ totalTasks: 0, completedTasks: 0, progress: 0 });
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [statsRes, historyRes] = await Promise.all([
        axios.get(`/api/stats?userId=${user.id}`),
        axios.get(`/api/history?userId=${user.id}`)
      ]);
      setStats(statsRes.data);
      setHistory(historyRes.data);
    } catch (err) {
      console.error('Dashboard fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-500">
            Welcome back, Student
          </h1>
          <p className="text-gray-400">Here's your academic performance overview.</p>
        </div>
        {!predictionResult && (
          <button 
            onClick={() => setActiveTab('predict')}
            className="glass-button flex items-center gap-2"
          >
            Start AI Prediction <ArrowRight size={18} />
          </button>
        )}
      </div>

      {/* Main Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Predicted Marks" 
          value={predictionResult ? `${predictionResult.predicted_marks}/100` : '--'} 
          subtext={predictionResult ? "Based on current study habits" : "Run prediction to see"} 
          icon={TrendingUp} 
          color="text-blue-400" 
        />
        <StatCard 
          title="Predicted Grade" 
          value={predictionResult ? predictionResult.predicted_grade : '--'} 
          subtext="Academic Standing" 
          icon={Brain} 
          color="text-purple-400" 
        />
        <StatCard 
          title="Attendance" 
          value="84.5%" 
          subtext="+2.3% from last week" 
          icon={Users} 
          color="text-cyan-400" 
        />
        <StatCard 
          title="Risk Level" 
          value={predictionResult ? predictionResult.risk_level : 'Unknown'} 
          subtext="Success Probability" 
          icon={Zap} 
          color={predictionResult?.risk_level === 'High' ? 'text-red-400' : 'text-green-400'} 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Chart */}
        <div className="lg:col-span-2 glass-card h-[400px]">
          <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
            <TrendingUp size={18} /> Consistency Tracking
          </h3>
          <ResponsiveContainer width="100%" height="85%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id="colorStudy" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
              <XAxis dataKey="name" stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#17171b', border: '1px solid #ffffff10', borderRadius: '12px' }}
                itemStyle={{ color: '#fff' }}
              />
              <Area type="monotone" dataKey="study" stroke="#3b82f6" fillOpacity={1} fill="url(#colorStudy)" strokeWidth={3} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Side Panel: Tasks & Quests */}
        <div className="glass-card">
          <h3 className="text-lg font-semibold mb-4">Quick Quests</h3>
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-white/5 border border-white/5 hover:border-blue-500/30 transition-all group">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">Academic</span>
                <Clock size={14} className="text-gray-500" />
              </div>
              <p className="text-sm font-medium mb-1">Complete Math Mock Test</p>
              <p className="text-xs text-gray-500">Reward: Unlock Logic Game</p>
            </div>
            
            <div className="p-4 rounded-xl bg-white/5 border border-white/5 hover:border-purple-500/30 transition-all group">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-purple-400 uppercase tracking-wider">Productivity</span>
                <Clock size={14} className="text-gray-500" />
              </div>
              <p className="text-sm font-medium mb-1">Maintain 7h Sleep Streak</p>
              <p className="text-xs text-gray-500">Reward: Bonus Confidence Pts</p>
            </div>

            <div className="p-4 rounded-xl bg-white/5 border border-white/5">
              <h4 className="text-sm font-semibold mb-3">Skill Distribution</h4>
              <div className="space-y-3">
                {[
                  { label: 'Aptitude', val: 75, color: 'bg-blue-500' },
                  { label: 'Coding', val: 60, color: 'bg-purple-500' },
                  { label: 'Soft Skills', val: 90, color: 'bg-cyan-500' }
                ].map(skill => (
                  <div key={skill.label}>
                    <div className="flex justify-between text-[10px] mb-1 text-gray-400 uppercase">
                      <span>{skill.label}</span>
                      <span>{skill.val}%</span>
                    </div>
                    <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
                      <div className={`h-full ${skill.color}`} style={{ width: `${skill.val}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

@echo off
echo ==============================================
echo   AetherNode V2.2 - Neural Platform Launcher
echo ==============================================
echo.

echo [1/2] Starting AI ML Service (Port 5000)...
start cmd /k "cd ml_service && python app.py"

echo [2/2] Starting Backend ^& UI Server (Port 5001)...
start cmd /k "cd server && node server.js"

echo.
echo Launching AetherNode Interface...
timeout /t 5
start http://localhost:5001

echo.
echo Platform is active. Please keep the terminal windows open.
